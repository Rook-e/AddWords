package com.mobiledev.addwords;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AddSecondWord extends AppCompatActivity {
    @Override
    public void onStart(){
        super.onStart();
        setContentView(R.layout.activity_addsecondword);

        //display words so far
        TextView concatDisplay = findViewById(R.id.concatDisplay);
        if (getIntent().getStringExtra("words") == null){

        } else concatDisplay.setText(getIntent().getStringExtra("words"));

        //create var to get second word
        final EditText eTSecondWord = findViewById(R.id.secondWord);

        //create var to set onClick listener on Button - secondNext
        Button next = findViewById(R.id.secondNext);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get second word from EditText
                String secondWord = eTSecondWord.getText().toString();

                //create intent - to store firstWord + secondWord and create new activity
                Intent goToThirdActivity = new Intent(AddSecondWord.this, AddThirdWord.class);

                //push data onto Intent object
                goToThirdActivity.putExtra("words", "" + getIntent().getStringExtra("words") + " " + secondWord);

                //start new activity
                startActivity(goToThirdActivity);
            }
        });
    }
}
