package com.mobiledev.addwords;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AddThirdWord extends AppCompatActivity {
    public void onStart(){
        super.onStart();
        setContentView(R.layout.activity_addthirdword);

        //Display words so far
        TextView concatDisplay = findViewById(R.id.concatDisplay);
        if (getIntent().getStringExtra("words") == null){

        } else concatDisplay.setText(getIntent().getStringExtra("words"));

        //create a var to get EditText
        final EditText eTThirdWord = findViewById(R.id.thirdWord);

        //create a var to get finish button and set onClick listener
        Button finish = findViewById(R.id.finish);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //store third word
                String thirdWord = eTThirdWord.getText().toString();

                //create intent to store third word and start new activity
                Intent goBackToMain = new Intent(AddThirdWord.this, MainActivity.class);
                goBackToMain.putExtra("words", "" + getIntent().getStringExtra("words") + " " + thirdWord);

                startActivity(goBackToMain);

            }
        });
    }
}
