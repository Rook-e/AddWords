package com.mobiledev.addwords;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    //log utility
    final String tag = "aj";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Display all three words
        TextView concatDisplay = findViewById(R.id.concatDisplay);
        if (getIntent().getStringExtra("words") == null){

        } else concatDisplay.setText(getIntent().getStringExtra("words"));

        // create var to get first word
        final EditText eTFirstWord = findViewById(R.id.firstWord);


        //set event listener
        Button next = findViewById(R.id.mainNext);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get text from editText
                String firstWord = eTFirstWord.getText().toString();

                //create intent
                Intent goToAddSecondWord = new Intent(MainActivity.this, AddSecondWord.class);
                //add data to intent Bundle object
                goToAddSecondWord.putExtra("words", firstWord);

                //create and start activity
                startActivity(goToAddSecondWord);
            }
        });


    }

}
